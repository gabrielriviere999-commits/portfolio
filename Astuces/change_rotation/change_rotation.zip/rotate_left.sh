#!/bin/bash

SCREEN="eDP-1"
TOUCH="ELAN9009:00 04F3:2EC1"

xrandr --output "$SCREEN" --rotate left
xinput set-prop "$TOUCH" "Coordinate Transformation Matrix" 0 -1 1 1 0 0 0 0 1
