#!/bin/bash

SCREEN="eDP-1"
TOUCH1="ELAN9009:00 04F3:2EC1"
TOUCH2="ELAN9009:00 04F3:2EC1 Stylus Pen (0)"
TOUCH3="ELAN9009:00 04F3:2EC1 Stylus Eraser (0)"

xrandr --output "$SCREEN" --rotate normal

# doigt
xinput set-prop "$TOUCH1" "Coordinate Transformation Matrix" 1 0 0 0 1 0 0 0 1

# stylet
xinput set-prop "$TOUCH2" "Coordinate Transformation Matrix" 1 0 0 0 1 0 0 0 1

# stylet effaceur
xinput set-prop "$TOUCH3" "Coordinate Transformation Matrix" 1 0 0 0 1 0 0 0 1
