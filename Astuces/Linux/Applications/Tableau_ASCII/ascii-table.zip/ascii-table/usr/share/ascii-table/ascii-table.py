#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GtkSource", "4")

import sys
sys.path.append("/usr/share/ascii-table")

from gi.repository import Gtk, GtkSource, Gdk
import subprocess

from ascii_core import lire_lignes_csv, generer_tableau
from config_manager import load_config, save_config


class AsciiTableApp(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Tableau ASCII")
        self.set_wmclass("ascii-table", "Ascii-table")
        self.set_icon_from_file("/usr/share/ascii-table/icon.png")
        Gtk.Window.set_default_icon_from_file("/usr/share/ascii-table/icon.png")
        self.set_default_size(700, 600)

        cfg = load_config()

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_border_width(10)
        self.add(vbox)

        # --- Paramètres ---
        params_box = Gtk.FlowBox()
        params_box.set_selection_mode(Gtk.SelectionMode.NONE)
        params_box.set_max_children_per_line(4)
        params_box.set_row_spacing(10)
        params_box.set_column_spacing(10)

        # Widgets des paramètres
        label_sep = Gtk.Label(label="Séparateur :")
        label_sep.set_xalign(0)

        label_max = Gtk.Label(label="Largeur max :")
        label_max.set_xalign(0)

        self.sep_entry = Gtk.Entry()
        self.sep_entry.set_text(cfg["sep"])
        self.sep_entry.connect("changed", self.save_settings)

        self.maxwidth_entry = Gtk.Entry()
        self.maxwidth_entry.set_text(cfg["maxwidth"])
        self.maxwidth_entry.connect("changed", self.save_settings)

        # Ajout dans le FlowBox
        params_box.add(label_sep)
        params_box.add(self.sep_entry)
        params_box.add(label_max)
        params_box.add(self.maxwidth_entry)

        vbox.pack_start(params_box, False, False, 0)

        # --- Zone d'entrée ---
        self.input_buffer = GtkSource.Buffer()
        self.input_view = GtkSource.View(buffer=self.input_buffer)
        self.input_view.set_hexpand(True)
        self.input_view.set_size_request(0, -1)
        self.input_view.set_wrap_mode(Gtk.WrapMode.NONE)
        self.input_view.set_show_line_numbers(False)

        self.input_scroller = Gtk.ScrolledWindow()
        self.input_scroller.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.input_scroller.set_hexpand(True)
        self.input_scroller.set_size_request(0, -1)
        self.input_scroller.add(self.input_view)

        vbox.pack_start(self.input_scroller, True, True, 0)

        # --- Boutons ---
        paste_btn = Gtk.Button(label="Coller")
        paste_btn.connect("clicked", self.coller)

        convert_btn = Gtk.Button(label="Convertir")
        convert_btn.connect("clicked", self.convertir)

        copy_btn = Gtk.Button(label="Copier")
        copy_btn.connect("clicked", self.copier)

        clear_btn = Gtk.Button(label="Effacer")
        clear_btn.connect("clicked", self.effacer)

        default_btn = Gtk.Button(label="Valeurs par défaut")
        default_btn.connect("clicked", self.reset_defaults)

        aide_btn = Gtk.Button(label="Aide")
        aide_btn.connect("clicked", self.afficher_raccourcis)

        buttons_box = Gtk.FlowBox()
        buttons_box.set_selection_mode(Gtk.SelectionMode.NONE)
        buttons_box.set_max_children_per_line(3)
        buttons_box.set_row_spacing(10)
        buttons_box.set_column_spacing(10)

        buttons_box.add(paste_btn)
        buttons_box.add(convert_btn)
        buttons_box.add(copy_btn)
        buttons_box.add(clear_btn)
        buttons_box.add(default_btn)
        buttons_box.add(aide_btn)

        vbox.pack_start(buttons_box, False, False, 0)

        # --- Résultat ---
        self.output_buffer = GtkSource.Buffer()
        self.output_view = GtkSource.View(buffer=self.output_buffer)
        self.output_view.set_hexpand(True)
        self.output_view.set_size_request(0, -1)
        self.output_view.set_editable(False)
        self.output_view.set_monospace(True)
        self.output_view.set_show_line_numbers(False)

        self.output_scroller = Gtk.ScrolledWindow()
        self.output_scroller.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.output_scroller.add(self.output_view)

        vbox.pack_start(self.output_scroller, True, True, 0)

        # Raccourcis clavier
        self.connect("key-press-event", self.on_key_press)

    # --- Raccourcis clavier ---
    def on_key_press(self, widget, event):
        state = event.state
        ctrl = state & Gdk.ModifierType.CONTROL_MASK
        shift = state & Gdk.ModifierType.SHIFT_MASK

        # Ctrl+Z → undo
        if ctrl and not shift and event.keyval == Gdk.KEY_z:
            if self.input_buffer.can_undo():
                self.input_buffer.undo()
            return True

        # Ctrl+Y → redo
        if ctrl and not shift and event.keyval == Gdk.KEY_y:
            if self.input_buffer.can_redo():
                self.input_buffer.redo()
            return True

        # Ctrl+Shift+Z → redo
        if ctrl and shift and event.keyval == Gdk.KEY_z:
            if self.input_buffer.can_redo():
                self.input_buffer.redo()
            return True

        # Ctrl+D → duplicate line
        if ctrl and not shift and event.keyval in (Gdk.KEY_d, Gdk.KEY_D):
            self.duplicate_current_line(self.input_buffer)
            return True

        # Ctrl+Shift+D → delete line
        if ctrl and shift and event.keyval in (Gdk.KEY_d, Gdk.KEY_D):
            self.delete_current_line(self.input_buffer)
            return True

        # Ctrl+Enter → Convertir
        if ctrl and event.keyval == Gdk.KEY_Return:
            self.convertir(None)
            return True

        # Ctrl+Shift+C → Copier
        if ctrl and shift and event.keyval in (Gdk.KEY_c, Gdk.KEY_C):
            self.copier(None)
            return True

        # Ctrl+Shift+E → Effacer
        if ctrl and shift and event.keyval in (Gdk.KEY_e, Gdk.KEY_E):
            self.effacer(None)
            return True

        # Ctrl+Shift+R → Valeurs par défaut
        if ctrl and shift and event.keyval in (Gdk.KEY_r, Gdk.KEY_R):
            self.reset_defaults(None)
            return True

        # Ctrl+Shift+V → Coller
        if ctrl and shift and event.keyval in (Gdk.KEY_v, Gdk.KEY_V):
            self.coller(None)
            return True

        return False

    # --- Aide ---
    def afficher_raccourcis(self, widget):
        texte = (
            "Ctrl + Z              Annuler\n"
            "Ctrl + Y              Rétablir\n"
            "Ctrl + Shift + Z      Rétablir\n"
            "Ctrl + D              Dupliquer la ligne\n"
            "Ctrl + Shift + D      Supprimer la ligne\n"
            "Ctrl + Enter          Convertir\n"
            "Ctrl + Shift + Enter  Convertir\n"
            "Ctrl + Shift + C      Copier\n"
            "Ctrl + Shift + V      Coller\n"
            "Ctrl + Shift + E      Effacer\n"
            "Ctrl + Shift + R      Valeurs par défaut\n\n"
            "Note : Dupliquer la dernière ligne crée une ligne vide."
        )

        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text="Raccourcis clavier",
        )

        # On remplace le texte secondaire par un label monospace
        label = Gtk.Label()
        label.set_use_markup(True)
        label.set_xalign(0)
        label.set_text("")  # éviter le texte par défaut
        label.set_markup(f"<tt>{texte}</tt>")

        # On insère le label dans la zone secondaire du dialog
        box = dialog.get_message_area()
        box.pack_end(label, False, False, 0)
        label.show()

        dialog.run()
        dialog.destroy()


    # --- Dupliquer la ligne ---
    def duplicate_current_line(self, buffer):
        insert_mark = buffer.get_insert()
        it = buffer.get_iter_at_mark(insert_mark)
        line = it.get_line()

        start = buffer.get_iter_at_line(line)

        if line + 1 < buffer.get_line_count():
            end = buffer.get_iter_at_line(line + 1)
        else:
            end = buffer.get_end_iter()
            last_line_text = buffer.get_text(start, end, True)
            if last_line_text != "" and not last_line_text.endswith("\n"):
                buffer.insert(end, "\n")
                end = buffer.get_end_iter()

        text = buffer.get_text(start, end, True)

        if not text.endswith("\n"):
            text += "\n"

        insert_pos = end.copy()
        buffer.insert(insert_pos, text)

        original_line_iter = buffer.get_iter_at_line(line)
        buffer.place_cursor(original_line_iter)

    # --- Supprimer la ligne ---
    def delete_current_line(self, buffer):
        insert_mark = buffer.get_insert()
        it = buffer.get_iter_at_mark(insert_mark)
        line = it.get_line()

        start = buffer.get_iter_at_line(line)

        if line + 1 < buffer.get_line_count():
            end = buffer.get_iter_at_line(line + 1)
        else:
            end = buffer.get_end_iter()

        buffer.delete(start, end)

    # --- Sauvegarde auto ---
    def save_settings(self, widget):
        sep = self.sep_entry.get_text()
        maxwidth = self.maxwidth_entry.get_text()
        save_config(sep, maxwidth)

    # --- Coller ---
    def coller(self, widget):
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)

        texte = clipboard.wait_for_text()
        if not texte:
            return

        # Si du texte est sélectionné → remplacer
        if self.input_buffer.get_has_selection():
            start, end = self.input_buffer.get_selection_bounds()
            self.input_buffer.delete(start, end)

        # Coller à la position du curseur
        self.input_buffer.insert_at_cursor(texte)

        self.input_view.grab_focus()
    
    # --- Conversion ---
    def convertir(self, widget):
        start, end = self.input_buffer.get_bounds()
        texte = self.input_buffer.get_text(start, end, True)

        sep = self.sep_entry.get_text() or ";"
        maxwidth = int(self.maxwidth_entry.get_text() or "120")

        lignes = lire_lignes_csv(texte, sep)
        tableau = generer_tableau(lignes, maxwidth)

        self.output_buffer.set_text(tableau)

    # --- Copier ---
    def copier(self, widget):
        start, end = self.output_buffer.get_bounds()
        texte = self.output_buffer.get_text(start, end, True)

        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        clipboard.set_text(texte, -1)

    # --- Effacer ---
    def effacer(self, widget):
        self.input_buffer.set_text("")
        self.output_buffer.set_text("")

    # --- Valeurs par défaut ---
    def reset_defaults(self, widget):
        self.sep_entry.set_text(";")
        self.maxwidth_entry.set_text("120")
        save_config(";", "120")


if __name__ == "__main__":
    app = AsciiTableApp()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()

    app.sep_entry.select_region(0, 0)
    app.input_view.grab_focus()

    Gtk.main()
