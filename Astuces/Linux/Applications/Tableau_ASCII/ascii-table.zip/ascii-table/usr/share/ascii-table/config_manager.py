import os
import configparser

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".config", "ascii-table")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.ini")


def load_config():
    config = configparser.ConfigParser()

    if not os.path.exists(CONFIG_FILE):
        return {"sep": ";", "maxwidth": "120"}

    config.read(CONFIG_FILE)

    return {
        "sep": config.get("settings", "sep", fallback=";"),
        "maxwidth": config.get("settings", "maxwidth", fallback="120")
    }


def save_config(sep, maxwidth):
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)

    config = configparser.ConfigParser()
    config["settings"] = {
        "sep": sep,
        "maxwidth": maxwidth
    }

    with open(CONFIG_FILE, "w") as f:
        config.write(f)
