import javax.swing.*;
import javax.swing.undo.*;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.util.List;
import java.util.prefs.Preferences;

public class AsciiTableApp extends JFrame {

    private JTextArea inputArea;
    private JTextArea outputArea;

    private JTextField sepField;
    private JTextField widthField;

    private UndoManager undoManager = new UndoManager();
    private Preferences prefs = Preferences.userRoot().node("ascii_table_app");

    public AsciiTableApp() {
        super("Tableau ASCII");

        try {
            Image icon = Toolkit.getDefaultToolkit().getImage("icon.png");
            setIconImage(icon);
        } catch (Exception e) {
            System.out.println("Impossible de charger l'icône.");
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // --- Paramètres ---
        JPanel params = new JPanel(new WrapLayout(FlowLayout.LEFT));
        params.add(new JLabel("Séparateur :"));
        sepField = new JTextField(prefs.get("sep", ";"), 3);
        params.add(sepField);

        params.add(new JLabel("Largeur max :"));
        widthField = new JTextField(prefs.get("width", "120"), 4);
        params.add(widthField);

        // sauvegarde auto
        sepField.getDocument().addDocumentListener(new AutoSaver(() -> {
            prefs.put("sep", sepField.getText());
            flushPrefs();
        }));

        widthField.getDocument().addDocumentListener(new AutoSaver(() -> {
            prefs.put("width", widthField.getText());
            flushPrefs();
        }));

        // --- Zones de texte ---
        inputArea = new JTextArea(10, 50);
        outputArea = new JTextArea(10, 50);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        inputArea.getDocument().addUndoableEditListener(undoManager);

        JScrollPane inputScroll = new JScrollPane(inputArea);
        JScrollPane outputScroll = new JScrollPane(outputArea);

        // --- Boutons ---
        JButton pasteBtn = new JButton("Coller");
        pasteBtn.addActionListener(e -> coller());

        JButton convertBtn = new JButton("Convertir");
        convertBtn.addActionListener(e -> convertir());

        JButton copyBtn = new JButton("Copier");
        copyBtn.addActionListener(e -> copier());

        JButton clearBtn = new JButton("Effacer");
        clearBtn.addActionListener(e -> effacer());

        JButton resetBtn = new JButton("Valeurs par défaut");
        resetBtn.addActionListener(e -> resetDefaults());

        JButton helpBtn = new JButton("Aide");
        helpBtn.addActionListener(e -> afficherAide());

        JPanel buttons = new JPanel(new WrapLayout(FlowLayout.LEFT));
        buttons.add(pasteBtn);
        buttons.add(convertBtn);
        buttons.add(copyBtn);
        buttons.add(clearBtn);
        buttons.add(resetBtn);
        buttons.add(helpBtn);

        // --- Layout principal ---
        JPanel center = new JPanel(new GridLayout(2, 1));
        center.add(inputScroll);
        center.add(outputScroll);

        setLayout(new BorderLayout());
        add(params, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        // --- Raccourcis clavier ---
        setupShortcuts();

        setVisible(true);
    }

    private void flushPrefs() {
        try { prefs.flush(); } catch (Exception ignored) {}
    }

    private void coller() {
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            String texte = (String) clipboard.getData(DataFlavor.stringFlavor);
            inputArea.replaceSelection(texte);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void copier() {
        String texte = outputArea.getText();
        StringSelection sel = new StringSelection(texte);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);
    }

    private void effacer() {
        inputArea.setText("");
        outputArea.setText("");
    }

    private void resetDefaults() {
        sepField.setText(";");
        widthField.setText("120");

        prefs.put("sep", ";");
        prefs.put("width", "120");
        flushPrefs();
    }

    private void afficherAide() {
        String aide = """
                Raccourcis clavier :

                Ctrl + Shift + V     : Coller
                Ctrl + Shift + C     : Copier
                Ctrl + Shift + E     : Effacer
                Ctrl + Enter         : Convertir
                Ctrl + Shift + Enter : Convertir
                Ctrl + Z             : Annuler
                Ctrl + Y             : Rétablir
                Ctrl + D             : Dupliquer la ligne
                Ctrl + Shift + D     : Supprimer la ligne
                Ctrl + Shift + R     : Valeurs par défaut
                F1                   : Aide
                """;

        JTextArea area = new JTextArea(aide);
        area.setFont(new Font("Monospaced", Font.PLAIN, 13));
        area.setEditable(false);
        area.setOpaque(false);

        JOptionPane.showMessageDialog(this, area, "Aide", JOptionPane.INFORMATION_MESSAGE);
    }

    private void convertir() {
        try {
            String texte = inputArea.getText();
            String sep = sepField.getText();
            int maxwidth = Integer.parseInt(widthField.getText());

            prefs.put("sep", sep);
            prefs.put("width", String.valueOf(maxwidth));
            flushPrefs();

            List<List<String>> lignes = AsciiGenerator.lireLignesCSV(texte, sep);
            String tableau = AsciiGenerator.genererTableau(lignes, maxwidth);

            outputArea.setText(tableau);

        } catch (Exception e) {
            outputArea.setText("Erreur : " + e.getMessage());
        }
    }

    private void setupShortcuts() {
        InputMap im = inputArea.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = inputArea.getActionMap();

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), "coller");
        am.put("coller", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { coller(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), "copier");
        am.put("copier", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { copier(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), "effacer");
        am.put("effacer", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { effacer(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, InputEvent.CTRL_DOWN_MASK), "convertir");
        am.put("convertir", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { convertir(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), "convertir_shift");
        am.put("convertir_shift", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { convertir(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK), "undo");
        am.put("undo", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (undoManager.canUndo()) undoManager.undo();
            }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK), "redo");
        am.put("redo", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (undoManager.canRedo()) undoManager.redo();
            }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), "reset");
        am.put("reset", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { resetDefaults(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), "aide");
        am.put("aide", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { afficherAide(); }
        });
        
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_DOWN_MASK), "duplicateLine");
        am.put("duplicateLine", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { dupliquerLigne(); }
        });

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), "deleteLine");
        am.put("deleteLine", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { supprimerLigne(); }
        });
    }

    private void dupliquerLigne() {
        try {
            int caret = inputArea.getCaretPosition();
            int line = inputArea.getLineOfOffset(caret);

            int lineStart = inputArea.getLineStartOffset(line);
            int lineEnd   = inputArea.getLineEndOffset(line);

            String ligne = inputArea.getText().substring(lineStart, lineEnd);

            // Sommes-nous sur la dernière ligne réelle ?
            boolean derniereLigne = (line == inputArea.getLineCount() - 1);

            if (derniereLigne) {
                // Ajouter un vrai saut de ligne pour éviter la fusion
                inputArea.insert("\n" + ligne, lineEnd);
            } else {
                inputArea.insert(ligne, lineEnd);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void supprimerLigne() {
        try {
            int start = inputArea.getSelectionStart();
            int end = inputArea.getSelectionEnd();

            int lineStart = inputArea.getLineStartOffset(inputArea.getLineOfOffset(start));
            int lineEnd   = inputArea.getLineEndOffset(inputArea.getLineOfOffset(end));

            inputArea.replaceRange("", lineStart, lineEnd);
        } catch (Exception ex) {
        ex.printStackTrace();
        }
    }

    private static class AutoSaver implements DocumentListener {
        private final Runnable saveAction;

        public AutoSaver(Runnable saveAction) {
            this.saveAction = saveAction;
        }

        public void insertUpdate(DocumentEvent e) { saveAction.run(); }
        public void removeUpdate(DocumentEvent e) { saveAction.run(); }
        public void changedUpdate(DocumentEvent e) { saveAction.run(); }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AsciiTableApp::new);
    }
}
