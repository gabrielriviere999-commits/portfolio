import java.util.ArrayList;
import java.util.List;

public class AsciiGenerator {

    public static List<List<String>> lireLignesCSV(String texte, String sep) {
        List<List<String>> lignes = new ArrayList<>();

        String[] rawLines = texte.split("\\R"); // gère \n et \r\n

        for (String ligne : rawLines) {
            String[] parts = ligne.split(sep, -1); // garder cellules vides
            List<String> row = new ArrayList<>();

            for (String p : parts) {
                row.add(p.trim());
            }

            lignes.add(row);
        }

        return lignes;
    }

    public static String genererTableau(List<List<String>> lignes, int maxwidth) {
        if (lignes.isEmpty()) return "";

        int cols = lignes.stream().mapToInt(List::size).max().orElse(0);

        int[] widths = new int[cols];
        for (List<String> row : lignes) {
            for (int i = 0; i < cols; i++) {
                String cell = i < row.size() ? row.get(i) : "";
                int w = Math.min(cell.length(), maxwidth);
                widths[i] = Math.max(widths[i], w);
            }
        }

        StringBuilder sb = new StringBuilder();

        Runnable ligneHorizontale = () -> {
            sb.append("+");
            for (int w : widths) sb.append("-".repeat(w + 2)).append("+");
            sb.append("\n");
        };

        ligneHorizontale.run();

        for (List<String> row : lignes) {

            // découpe verticale
            List<List<String>> segments = new ArrayList<>();
            int maxSegments = 1;

            for (int i = 0; i < cols; i++) {
                String cell = i < row.size() ? row.get(i) : "";
                List<String> parts = new ArrayList<>();

                for (int pos = 0; pos < cell.length(); pos += maxwidth) {
                    parts.add(cell.substring(pos, Math.min(pos + maxwidth, cell.length())));
                }

                if (parts.isEmpty()) parts.add("");

                segments.add(parts);
                maxSegments = Math.max(maxSegments, parts.size());
            }

            for (int line = 0; line < maxSegments; line++) {
                sb.append("|");
                for (int col = 0; col < cols; col++) {
                    List<String> parts = segments.get(col);
                    String cell = line < parts.size() ? parts.get(line) : "";

                    sb.append(" ").append(cell);
                    sb.append(" ".repeat(widths[col] - cell.length()));
                    sb.append(" |");
                }
                sb.append("\n");
            }

            ligneHorizontale.run();
        }

        return sb.toString();
    }
}
