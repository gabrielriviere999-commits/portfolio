import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from http.server import SimpleHTTPRequestHandler, HTTPServer
import hashlib
import urllib.parse

DATA_FILE = "data.txt"
SEP = "\n===MSG===\n"

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def sha1(txt):
    return hashlib.sha1(txt.encode("utf-8")).hexdigest()

class Handler(SimpleHTTPRequestHandler):

    def do_GET(self):

        # Liste des fichiers
        if self.path == "/files":
            files = os.listdir(UPLOAD_DIR)
            out = "\n".join(files)

            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(out.encode("utf-8"))
            return

        # Téléchargement
        if self.path.startswith("/download?file="):
            raw = self.path.split("=", 1)[1]
            name = urllib.parse.unquote(raw)
            name = name.replace("/", "").replace("\\", "")

            path = os.path.join(UPLOAD_DIR, name)

            if not os.path.exists(path):
                self.send_response(404)
                self.end_headers()
                return

            size = os.path.getsize(path)

            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", f"attachment; filename=\"{name}\"")
            self.send_header("Content-Length", str(size))
            self.end_headers()

            with open(path, "rb") as f:
                self.wfile.write(f.read())
            return

        # Suppression GET (compatible 3DS + redirection PC)
        if self.path.startswith("/deletefile?name="):
            raw = self.path.split("=", 1)[1]
            name = urllib.parse.unquote(raw)
            name = name.replace("/", "").replace("\\", "")

            path = os.path.join(UPLOAD_DIR, name)

            if os.path.exists(path):
                os.remove(path)

            ua = self.headers.get("User-Agent", "")
            is3ds = "Nintendo 3DS" in ua

            if is3ds:
                # Page simple pour éviter 032-1209
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"<html><body>Fichier supprime</body></html>")
            else:
                # Redirection PC / Android
                self.send_response(302)
                self.send_header("Location", "/files.html")
                self.end_headers()
            return

        # Messages
        if self.path == "/messages":
            self.handle_messages()
            return

        super().do_GET()

    def do_POST(self):

        # Upload moderne
        if self.path == "/upload":
            length = int(self.headers["Content-Length"])
            data = self.rfile.read(length)

            filename = self.headers.get("X-Filename", "upload.bin")
            filename = filename.replace("/", "").replace("\\", "")

            path = os.path.join(UPLOAD_DIR, filename)

            with open(path, "wb") as f:
                f.write(data)

            self.send_response(200)
            self.end_headers()
            return

        # Upload 3DS multipart
        if self.path == "/upload_multipart":
            filename = self.handle_multipart()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body>OK</body></html>")
            return

        # Messages
        if self.path == "/send":
            self.handle_send()
            return

        if self.path == "/delete":
            self.handle_delete()
            return

        super().do_POST()

    def handle_messages(self):
        if not os.path.exists(DATA_FILE):
            open(DATA_FILE, "w").close()

        with open(DATA_FILE, "r", encoding="utf-8") as f:
            blocs = [b for b in f.read().split(SEP) if b.strip()]

        out = ""
        for b in blocs:
            out += sha1(b) + "\n" + b + SEP

        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(out.encode("utf-8"))

    def handle_send(self):
        length = int(self.headers["Content-Length"])
        body = self.rfile.read(length).decode("utf-8")

        with open(DATA_FILE, "a", encoding="utf-8") as f:
            f.write(body + SEP)

        self.send_response(200)
        self.end_headers()

    def handle_delete(self):
        length = int(self.headers["Content-Length"])
        h = self.rfile.read(length).decode("utf-8")

        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                blocs = [b for b in f.read().split(SEP) if b.strip()]

            new = [b for b in blocs if sha1(b) != h]

            with open(DATA_FILE, "w", encoding="utf-8") as f:
                for b in new:
                    f.write(b + SEP)

        self.send_response(200)
        self.end_headers()

    def handle_multipart(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            return None

        boundary = content_type.split("boundary=")[1].encode()
        remainbytes = int(self.headers['Content-Length'])

        line = self.rfile.readline()
        remainbytes -= len(line)
        if boundary not in line:
            return None

        line = self.rfile.readline()
        remainbytes -= len(line)

        dispo = line.decode("utf-8", "ignore")
        if "filename=" not in dispo:
            return None
        filename = dispo.split("filename=", 1)[1].strip().strip('"')
        filename = filename.replace("/", "").replace("\\", "")

        line = self.rfile.readline()
        remainbytes -= len(line)

        line = self.rfile.readline()
        remainbytes -= len(line)

        path = os.path.join(UPLOAD_DIR, filename)
        out = open(path, "wb")

        preline = self.rfile.readline()
        remainbytes -= len(preline)

        while remainbytes > 0:
            line = self.rfile.readline()
            remainbytes -= len(line)
            if boundary in line:
                out.write(preline[:-2])
                out.close()
                return filename
            else:
                out.write(preline)
                preline = line

        out.close()
        return filename

HTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
