import java.util.ArrayList;
import java.util.List;

public class AsciiGenerator {

    // --- WRAP INTELLIGENT ---
    private static List<String> wrap(String s, int max) {
        List<String> lines = new ArrayList<>();

        if (s == null || s.length() == 0) {
            lines.add("");
            return lines;
        }

        String[] words = s.split(" ");
        String current = "";

        for (String w : words) {

            if (w.length() > max) {

                if (!current.isEmpty()) {
                    lines.add(current);
                    current = "";
                }

                int start = 0;
                while (start < w.length()) {
                    int end = Math.min(start + max, w.length());
                    String chunk = w.substring(start, end);
                    start += max;

                    if (start >= w.length()) {
                        current = chunk;
                    } else {
                        lines.add(chunk);
                    }
                }

                continue;
            }

            if (current.isEmpty()) {
                current = w;
            } else if (current.length() + 1 + w.length() <= max) {
                current += " " + w;
            } else {
                lines.add(current);
                current = w;
            }
        }

        if (!current.isEmpty()) {
            lines.add(current);
        }

        return lines;
    }

    // --- CSV → LIGNES ---
    public static List<List<String>> lireLignesCSV(String texte, String sep) {
        List<List<String>> lignes = new ArrayList<>();

        String[] rawLines = texte.split("\\R");

        for (String ligne : rawLines) {
            String[] parts = ligne.split(sep, -1);
            List<String> row = new ArrayList<>();

            for (String p : parts) {
                row.add(p.trim());
            }

            lignes.add(row);
        }

        return lignes;
    }

    // --- TABLE ASCII ---
    public static String genererTableau(List<List<String>> lignes, int maxwidth) {
        if (lignes.isEmpty()) return "";

        int cols = lignes.stream().mapToInt(List::size).max().orElse(0);

        int[] widths = new int[cols];
        for (List<String> row : lignes) {
            for (int i = 0; i < cols; i++) {
                String cell = i < row.size() ? row.get(i) : "";
                int w = Math.min(cell.length(), maxwidth);
                widths[i] = Math.max(widths[i], w);
            }
        }

        StringBuilder sb = new StringBuilder();

        Runnable ligneHorizontale = () -> {
            sb.append("+");
            for (int w : widths) sb.append("-".repeat(w + 2)).append("+");
            sb.append("\n");
        };

        ligneHorizontale.run();

        for (List<String> row : lignes) {

            List<List<String>> segments = new ArrayList<>();
            int maxSegments = 1;

            for (int i = 0; i < cols; i++) {
                String cell = i < row.size() ? row.get(i) : "";
                List<String> parts = wrap(cell, maxwidth);

                if (parts.isEmpty()) parts.add("");

                segments.add(parts);
                maxSegments = Math.max(maxSegments, parts.size());
            }

            for (int line = 0; line < maxSegments; line++) {
                sb.append("|");
                for (int col = 0; col < cols; col++) {
                    List<String> parts = segments.get(col);
                    String cell = line < parts.size() ? parts.get(line) : "";

                    sb.append(" ").append(cell);
                    sb.append(" ".repeat(widths[col] - cell.length()));
                    sb.append(" |");
                }
                sb.append("\n");
            }

            ligneHorizontale.run();
        }

        return sb.toString();
    }
}
