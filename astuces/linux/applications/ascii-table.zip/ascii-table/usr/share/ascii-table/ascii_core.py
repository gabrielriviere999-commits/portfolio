# ascii_core.py
import textwrap
import re

def lire_lignes_csv(texte, sep):
    """
    Découpe les lignes selon un séparateur arbitraire (multi-caractères OK).
    Utilise re.split pour gérer tous les cas.
    """
    pattern = re.escape(sep)

    lignes = []
    for ligne in texte.splitlines():
        champs = re.split(pattern, ligne)
        lignes.append(champs)

    return lignes


def normaliser_lignes(lignes):
    """
    S'assure que toutes les lignes ont le même nombre de colonnes.
    Évite les IndexError dans les tableaux irréguliers.
    """
    max_cols = max(len(l) for l in lignes)
    return [l + [""] * (max_cols - len(l)) for l in lignes]


def largeurs_colonnes(lignes):
    return [
        max(len(str(row[c])) for row in lignes)
        for c in range(len(lignes[0]))
    ]


def ajuster_largeurs_dynamique(largeurs, max_width):
    nb = len(largeurs)
    bordures = 3 * nb + 1
    espace = max_width - bordures

    if espace <= nb:
        return [1] * nb

    total_naturel = sum(largeurs)

    if total_naturel <= espace:
        return largeurs[:]

    nouvelles = [max(1, int(w * espace / total_naturel)) for w in largeurs]

    diff = espace - sum(nouvelles)
    i = 0
    while diff != 0:
        idx = i % nb
        if diff > 0:
            nouvelles[idx] += 1
            diff -= 1
        elif nouvelles[idx] > 1:
            nouvelles[idx] -= 1
            diff += 1
        i += 1

    return nouvelles


def separateur_ligne(largeurs):
    return "+" + "+".join("-" * (w + 2) for w in largeurs) + "+"


def wrap_cell(cell, largeur):
    texte = str(cell)
    if not texte:
        return [""]

    words = texte.split(" ")
    lines = []
    current = ""

    for w in words:

        # --- Mot trop long : découpe par caractères ---
        if len(w) > largeur:

            # Si la ligne courante contient quelque chose → on la pousse
            if current:
                lines.append(current)
                current = ""

            start = 0
            while start < len(w):
                chunk = w[start:start+largeur]
                start += largeur

                # La dernière tranche devient la ligne courante
                if start >= len(w):
                    current = chunk
                else:
                    lines.append(chunk)

            continue

        # --- Mot normal ---
        if not current:
            current = w
        elif len(current) + 1 + len(w) <= largeur:
            current += " " + w
        else:
            lines.append(current)
            current = w

    if current:
        lines.append(current)

    return lines


def generer_tableau(lignes, max_width):
    if not lignes:
        return ""

    # Normalisation pour éviter les erreurs
    lignes = normaliser_lignes(lignes)

    largeurs = largeurs_colonnes(lignes)
    largeurs = ajuster_largeurs_dynamique(largeurs, max_width)

    sep_line = separateur_ligne(largeurs)
    resultat = [sep_line]

    for ligne in lignes:
        cellules = [
            wrap_cell(cell, w)
            for cell, w in zip(ligne, largeurs)
        ]

        hauteur = max(len(c) for c in cellules)

        for i in range(hauteur):
            row = "| "
            for cell_lines, w in zip(cellules, largeurs):
                texte = cell_lines[i] if i < len(cell_lines) else ""
                row += texte.ljust(w) + " | "
            resultat.append(row.rstrip())

        resultat.append(sep_line)

    return "\n".join(resultat)
